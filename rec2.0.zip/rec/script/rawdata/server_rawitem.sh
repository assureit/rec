#!/bin/sh

./serverA_CPU.js
./REC_LoadAvg.js
./REC_SwapSize.js
./REC_DiskRead.js
./REC_DiskWrite.js
./REC_DiskFreePer.js
./REC_NicIn.js
./REC_NicOut.js

